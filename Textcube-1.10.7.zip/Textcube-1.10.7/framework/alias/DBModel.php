<?php
/// Copyright (c) 2004-2015, Needlworks  / Tatter Network Foundation
/// All rights reserved. Licensed under the GPL.
/// See the GNU General Public License for more details. (/documents/LICENSE, /documents/COPYRIGHT)
	
	if(!class_exists('DBAdapter')) require_once (ROOT.'/framework/alias/DBAdapter,php');
	require_once(ROOT."/framework/model/IModel.php");
	require_once(ROOT."/framework/data/DBModel.php");
?>
