<?php
/**
 * PHPMailer language file.  
 * Czech Version
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'Mus�te zadat alespo� jednu ' .
                                     'emailovou adresu p��jemce.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailov� klient nen� podporov�n.';
$PHPMAILER_LANG["execute"] = 'Nelze prov�st: ';
$PHPMAILER_LANG["instantiate"] = 'Nelze vytvo�it instanci emailov� funkce.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Error: Chyba autentikace.';
$PHPMAILER_LANG["from_failed"] = 'N�sleduj�c� adresa From je nespr�vn�: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Error: Adresy p��jemc� ' .
                                       'nejsou spr�vn� ' .
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Error: Data nebyla p�ijata';
$PHPMAILER_LANG["connect_host"] = 'SMTP Error: Nelze nav�zat spojen� se ' .
                                  ' SMTP serverem.';
$PHPMAILER_LANG["file_access"] = 'Soubor nenalezen: ';
$PHPMAILER_LANG["file_open"] = 'File Error: Nelze otev��t soubor pro �ten�: ';
$PHPMAILER_LANG["encoding"] = 'Nezn�m� k�dov�n�: ';
?>