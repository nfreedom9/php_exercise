							<ul id="link-tabs-box" class="tabs-box">
								<li<?php echo isset($tabsClass['cover']) ? ' class="selected"' : NULL;?>><a href="<?php echo $context->getProperty('uri.blog');?>/owner/skin/coverpage"><?php echo _t('표지 위젯');?></a></li>
								<li<?php echo isset($tabsClass['sidebar']) ? ' class="selected"' : NULL;?>><a href="<?php echo $context->getProperty('uri.blog');?>/owner/skin/sidebar"><?php echo _t('사이드바 위젯');?></a></li>
							</ul>
